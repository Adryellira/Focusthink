import React from 'react'

import { MMKV } from 'react-native-mmkv'
const storage = new MMKV()

export default function Followers() {
  return <></>
}
