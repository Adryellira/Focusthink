let pontuacao = 0

const getPontuacao = () => {
  return pontuacao
}

const incrementarPontuacao = () => {
  pontuacao++
}

const resetarPontuacao = () => {
  pontuacao = 0
}

export { getPontuacao, incrementarPontuacao, resetarPontuacao }
