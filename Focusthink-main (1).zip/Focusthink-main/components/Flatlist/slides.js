export default [
    {
        id: '1',
        tittle: '',
        description: 'Boas-vindas! Estamos prestes a embarcar em uma jornada para aprimorar suas habilidades mentais!',
        image: require('../../assets/gametesticon.png')
    },
    {
        id: '2',
        tittle: '',
        description: 'Boas-vindas! Estamos prestes a embarcar em uma jornada para aprimorar suas habilidades mentais!',
        image: require('../../assets/gametesticon.png')
    },
    {
        id: '3',
        tittle: '',
        description: 'Boas-vindas! Estamos prestes a embarcar em uma jornada para aprimorar suas habilidades mentais!',
        image: require('../../assets/gametesticon.png')
    },
]